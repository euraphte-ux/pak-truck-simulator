# Pak Truck Simulator Android
Installable Android build of the Pak Truck Simulator game.

Features: Pakistani decorated truck, touch steering, accelerator, brake, reverse, horn variants, traffic, deliveries, rupees, fuel, damage, day/night, persistent progress.

This project is intentionally dependency-light and uses Android WebView to run the local game offline.
